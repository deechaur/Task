function validateForm() {
    var x = document.forms["myForm"]["name"].value;
   
    var q = document.forms["myForm"]["email"].value;
    var atpos = q.indexOf("@");
    var dotpos = q.lastIndexOf(".");  
    
    var y = document.forms["myForm"]["password"].value;
    var password = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/; 

    var z = document.forms["myForm"]["mobile"].value;
    
    var p = document.forms["myForm"]["dob"].value;
    var minDate = new Date('01/01/1965');
    var maxDate =  new Date('12/31/1995');

   var r = document.forms["myForm"]["gender"].value;
   var s = document.forms["myForm"]["hobbies"].value;
   var t = document.forms["myForm"]["profilePic"].value;
   var u = document.forms["myForm"]["address"].value;


    
   
     if (x==null || x=="") {
        alert("Name must be filled out");
        return false;
    }

    if(atpos<1 || dotpos<atpos+2 || dotpos+2>=q.length) {
        alert("Not a valid e-mail address");
        return false;
    }
 
    if(y.length<8||y.length>15){  
        alert("Not the required password");  
 	return false;  
    } 
  
    if(y.value.match(password))   
     {  
     }  
        else  
    {   
            alert('Wrong Password!!!!')  
             return false;  
    }  

   if (u==null || u=="") {
        alert("Address must be filled out");
        return false;
    }


     if (isNaN(z)||z.length!=10){  
          document.getElementById("numloc").innerHTML="Enter Numeric value of 10 digits.";   
         return false;  
    } 
  
        if (r==null || r=="") {
        alert("Select any gender");
        return false;
    }

        if (s==null || s=="") {
        alert ("Select any hobby");
        return false;
   }

       if (t==null || t=="") {
        alert("Select a profile Image");
	return false;
    }



     if (p > minDate && p < maxDate ){
         return true;
    }	

	else{
        alert('Date outside range !!')
        return false;
    }

�
}
    
   